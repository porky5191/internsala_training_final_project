package porky.training.zypko.interfaces

interface OnAlertClick {
    fun onClick()
}