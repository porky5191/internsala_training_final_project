package porky.training.zypko.interfaces

interface MenuInterface {
    companion object {
        const val ID = "id"
        const val NAME = "name"
        const val COST_FOR_ONE = "cost_for_one"
        const val RESTAURANT_ID = "restaurant_id"
    }
}