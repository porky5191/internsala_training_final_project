package porky.training.zypko.model

class FAQ {
    var question: String? = null
    var answer: String? = null

}