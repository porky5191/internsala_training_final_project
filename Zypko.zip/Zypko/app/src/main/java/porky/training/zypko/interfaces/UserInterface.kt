package porky.training.zypko.interfaces

interface UserInterface {
    companion object {
        const val USER_ID = "user_id"
        const val NAME = "name"
        const val MOBILE_NO = "mobile_number"
        const val PASSWORD = "password"
        const val ADDRESS = "address"
        const val EMAIL = "email"
        const val OTP = "otp"
    }
}