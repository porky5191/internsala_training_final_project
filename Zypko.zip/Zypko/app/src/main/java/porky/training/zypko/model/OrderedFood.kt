package porky.training.zypko.model

class OrderedFood {
    var foodItemId = 0
    var foodName: String? = null
    var cost = 0.0

}