package porky.training.zypko.interfaces

interface DrawerLocker {
    fun setDrawerEnable(enable: Boolean)
}