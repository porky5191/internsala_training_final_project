package porky.training.zypko.model

class User {
    var userId = 0
    var name: String? = null
    var mobileNo: String? = null
    var password: String? = null
    var address: String? = null
    var email: String? = null

}