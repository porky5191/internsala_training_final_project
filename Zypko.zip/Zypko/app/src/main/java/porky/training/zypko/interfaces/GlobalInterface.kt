package porky.training.zypko.interfaces

interface GlobalInterface {
    companion object {
        const val STRING_DEFAULT_VALUE = ""

        //Response
        const val DATA      = "data"
        const val SUCCESS   = "success"
    }
}