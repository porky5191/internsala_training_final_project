package porky.training.zypko.interfaces

import porky.training.zypko.model.Menu
import java.util.*

interface AddToCartInterface {
    fun update(list: ArrayList<Menu?>?)
}